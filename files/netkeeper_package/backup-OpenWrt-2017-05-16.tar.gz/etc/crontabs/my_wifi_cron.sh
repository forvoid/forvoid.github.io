leep 100
DATE=`date +%Y-%m-%d-%H:%M:%S`
tries=0
echo --- my_watchdog start ---
while [[ $tries -lt 5 ]]
do
        if /bin/ping -c 1 8.8.8.8 >/dev/null 
        then
                echo --- exit ---

                echo $DATE OK >>/root/my_watchdog.log
                exit 0
        fi
        tries=$((tries+1))
        sleep 10
#       echo $DATE tries: $tries >>my_watchdog.log
ntpd -q -p 202.202.43.198
echo $DATE network restart >> /root/error.log
done
echo $DATE network restart >>my_watchdog.log
/etc/init.d/network restart
#echo $DATE reboot >>my_watchdog.log
#reboot
